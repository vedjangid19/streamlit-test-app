from flask import Flask, render_template, request, redirect, jsonify
import time
from db import get_db_connection, init_db, insert_user, get_user_by_mobile, reset_user_record
from otp_service import generate_otp, send_otp_sms
from unique_code_generator import generate_unique_code
import random
from datetime import datetime
from machine_dispatcher import notify_machine_to_dispatch


app = Flask(__name__)

# Route to display the form for collecting the bag
@app.route('/collect_bag', methods=['GET'])
def collect_bag_form():
    return render_template('collect_bag.html')

# Route to handle the form submission for collecting the bag
@app.route('/collect_bag', methods=['POST'])
def collect_bag():
    mobile = request.form['mobile']
    collection_code = request.form['collection_code']

    # Query the database to check if the mobile number and collection code match
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE mobile = ? AND unique_code = ?", (mobile, collection_code))
    user = cursor.fetchone()

    if user:
        # If user found, notify the machine to dispatch the bag
        machine_id = user['machine_id']
        is_dispatched = notify_machine_to_dispatch(machine_id, collection_code)

        # Update query to modify the record based on mobile and machine_id
        cursor.execute('''
            UPDATE users
            SET collected_timestamp = ?, collected_date = ?, collected = ?
            WHERE mobile = ? AND machine_id = ?;
        ''', (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),datetime.now().strftime("%Y-%m-%d"), 1,  mobile, machine_id))

        conn.commit()
        conn.close()

        if is_dispatched:
            return jsonify({"message": "Bag dispatched successfully!"})
        else:
            return jsonify({"message": "Failed to dispatch bag. Please try again."})
    else:
        return jsonify({"message": "Invalid mobile number or collection code."})
    
# Route to display the form
@app.route('/vending/<machine_id>', methods=['GET'])
def vending_form(machine_id):
    return render_template('vending_form.html', machine_id=machine_id)

# Route to handle form submission and OTP generation
@app.route('/submit_details', methods=['POST'])
def submit_details():
    name = request.form['name']
    mobile = request.form['mobile']
    city = request.form['city']
    area = request.form['area']
    pin_code = request.form['pin_code']
    machine_id = request.form['machine_id']
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    date = datetime.now().strftime("%Y-%m-%d")


    # Generate OTP and send SMS
    otp = generate_otp()
    # print(otp,name,mobile,city,area,pin_code,machine_id)
    print(f"OTP: {otp}\nName: {name}\nMobile: {mobile}\nCity: {city}\nArea: {area}\nPin Code: {pin_code}\nMachine ID: {machine_id}")
    
    msg_body = f"Your varification OTP for vending machine [ {machine_id} ]: {otp}",
    send_otp_sms(mobile, msg_body)

    insert_user(
        name=name, 
        mobile=mobile, 
        city="New York", 
        area="Manhattan", 
        pin_code="10001", 
        machine_id="M1234",
        otp=otp,
        timestamp=timestamp, 
        date=date
    )


    return render_template('verify_otp.html', mobile=mobile, machine_id=machine_id)

# Route to verify OTP
@app.route('/verify_otp', methods=['POST'])
def verify_otp():
    mobile = request.form['mobile']
    machine_id = request.form['machine_id']
    entered_otp = request.form['otp']
    user_record = get_user_by_mobile(mobile=mobile)
    get_generated_otp = int(user_record['otp'])
    # Check OTP
    if get_generated_otp == int(entered_otp):
        # OTP verified, save data to the database
        conn = get_db_connection()
        cursor = conn.cursor()

        # Check if user has already collected a bag
        cursor.execute("SELECT * FROM users WHERE mobile = ? AND machine_id = ? AND collected = 1", (mobile, request.form['machine_id']))
        user = cursor.fetchone()

        if user:
            return jsonify({"message": "You have already collected a bag. Please try again next month."})

        # Save the user data with timestamp and unique code
        unique_code = generate_unique_code()
        # cursor.execute('''
        #     INSERT INTO users (updated_timestamp, updated_date, unique_code, collected)
        #     VALUES (?, ?, ?, ?)
        # ''', (time.time(), time.strftime('%Y-%m-%d'), unique_code, 0))

        # Update query to modify the record based on mobile and machine_id
        cursor.execute('''
            UPDATE users
            SET updated_timestamp = ?, updated_date = ?, unique_code = ?, collected = ?, is_verify =?
            WHERE mobile = ? AND machine_id = ?;
        ''', (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), datetime.now().strftime("%Y-%m-%d"), unique_code, 0, 1,  mobile, machine_id))

        conn.commit()
        conn.close()

        msg_body = f"""OTP Verified. Here is your unique code for collection bag from machine: [ {machine_id} ]

                    Collection code is: {unique_code}
                    """,
        machine_number = '+919769496162'
        send_otp_sms(machine_number, msg_body)

        return jsonify({"message": "OTP Verified. Here is your unique code for collection: ", "unique_code": unique_code})

    else:
        return jsonify({"message": "Invalid OTP. Please try again."})


# POST API to reset user record
@app.route('/reset-record', methods=['POST'])
def reset_record():

    # Call the function to reset the record
    reset_user_record()

    # Respond with success
    return jsonify({'message': 'Record has been reset successfully'}), 200

# Run the app
if __name__ == "__main__":
    init_db()
    app.run(debug=True)
