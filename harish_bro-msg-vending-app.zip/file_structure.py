import os

# Define the folder structure
folder_structure = {
    "vending_machine_app": [
        "app.py",
        "config.py",
        "db.py",
        "otp_service.py",
        "unique_code_generator.py",
        {
            "templates": [
                "vending_form.html",
                "verify_otp.html"
            ]
        },
        {
            "static": [
                {
                    "qr_codes": []
                }
            ]
        },
        "requirements.txt"
    ]
}

# Function to create the folder structure
def create_structure(base_path, structure):
    for item in structure:
        if isinstance(item, dict):  # If the item is a folder with subfolders
            for folder, subfolders in item.items():
                folder_path = os.path.join(base_path, folder)
                os.makedirs(folder_path, exist_ok=True)
                create_structure(folder_path, subfolders)  # Recursive call for subfolders
        else:
            file_path = os.path.join(base_path, item)
            if not os.path.exists(file_path):  # Only create files if they don't exist
                with open(file_path, 'w') as f:
                    pass  # Create an empty file

# Base path for the project
base_path = "./vending_machine_app"

# Create the folder structure
os.makedirs(base_path, exist_ok=True)
create_structure(base_path, folder_structure["vending_machine_app"])

print("Folder structure created successfully!")
